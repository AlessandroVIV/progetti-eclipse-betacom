package com.betacom.jdbc.exceptions;

public class AcademyException extends Exception{

	public AcademyException() {
		super();
	}
	
	public AcademyException(String messaggio) {
		super(messaggio);
	}
	
}