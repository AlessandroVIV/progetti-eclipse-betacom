package com.betacom.jdbc.process.interfaces;

public interface SQLProcess {

	boolean execute();
	
}
